# Black Friday: Midnight Meltdown event text
mod-com-blackfriday-midnight--meltdown-cable_start = A submarine cable cut is disrupting connectivity during the Black Friday rush. Check routing and communicate with affected customers.
    .eng = Black Friday cable incident: connectivity is degraded. Check network paths and customer impact.
mod-com-blackfriday-midnight--meltdown-cable_end = Connectivity has been restored after the cable incident. Confirm services are healthy before the next shopping peak.
